const $ = (s, root=document) => root.querySelector(s);
const panel = $("#toolPanel"), statusEl = $("#status");
$("#year").textContent = new Date().getFullYear();
$("#menuToggle").addEventListener("click",()=>{const nav=$(".desktop-nav");nav.classList.toggle("open");$("#menuToggle").setAttribute("aria-expanded",nav.classList.contains("open"));});
const descriptions = {
  jpgpdf:["JPG to PDF","Convert JPG or PNG images into a single PDF. Images are fitted onto separate pages."],
  compress:["Image Compressor","Reduce image file size. Choose a quality level and download the compressed image."],
  merge:["Merge PDF","Combine two or more PDF files into one PDF, in the order you select."],
  ocr:["Image to Text","Extract text from a clear image. OCR language: English by default."]
};
function setStatus(msg, error=false){statusEl.textContent=msg;statusEl.className="status"+(error?" error":"");}
function openTool(name){
  const [title,desc]=descriptions[name];$("#workspaceTitle").textContent=title;$("#workspaceDescription").textContent=desc;setStatus("");
  const configs={
    jpgpdf:{accept:"image/jpeg,image/png",multiple:true,label:"Choose JPG or PNG images",button:"Convert to PDF",hint:"Select one or more JPG or PNG files. Each image becomes a page."},
    compress:{accept:"image/jpeg,image/png,image/webp",multiple:false,label:"Choose an image",button:"Compress image",hint:"Supported: JPG, PNG and WebP. PNG transparency may be flattened to white."},
    merge:{accept:"application/pdf,.pdf",multiple:true,label:"Choose PDF files",button:"Merge PDFs",hint:"Select at least two PDF files. They will be merged in the selected order."},
    ocr:{accept:"image/jpeg,image/png,image/webp",multiple:false,label:"Choose an image",button:"Extract text",hint:"Use a sharp, well-lit image for best results. OCR currently uses English."}
  };
  const c=configs[name];
  panel.innerHTML=`<div class="tool-form"><h3>${title}</h3><p>${hintText(c.hint)}</p><label class="dropzone" for="filePicker"><span class="upload-icon">⇧</span><b>${c.label}</b><small>Tap to browse files on your device</small></label><input class="file-input" id="filePicker" type="file" accept="${c.accept}" ${c.multiple?"multiple":""}><div class="file-list" id="fileList">No files selected</div>${name==="compress"?'<div class="range-row"><label for="quality">Quality</label><input id="quality" type="range" min="20" max="95" value="75"><b id="qualityValue">75%</b></div>':''}<div class="form-row"><button class="action-button" id="runTool" disabled>${c.button} →</button><button class="action-button secondary-button" id="clearFiles" type="button">Clear</button></div><div id="result"></div></div>`;
  const picker=$("#filePicker"),run=$("#runTool"),list=$("#fileList");
  picker.addEventListener("change",()=>{const files=[...picker.files];list.textContent=files.length?files.map((f,i)=>`${i+1}. ${f.name} · ${formatSize(f.size)}`).join(" | "):"No files selected";run.disabled=!files.length;if(name==="merge"&&files.length<2){run.disabled=true;setStatus("Please select at least two PDF files.");}else setStatus("");});
  $("#clearFiles").addEventListener("click",()=>{picker.value="";list.textContent="No files selected";run.disabled=true;$("#result").innerHTML="";setStatus("");});
  if(name==="compress")$("#quality").addEventListener("input",e=>$("#qualityValue").textContent=e.target.value+"%");
  run.addEventListener("click",async()=>{run.disabled=true;$("#result").innerHTML="";try{setStatus("Working… please keep this page open.");const files=[...picker.files];if(name==="jpgpdf")await jpgToPdf(files);if(name==="compress")await compressImage(files[0],Number($("#quality").value)/100);if(name==="merge")await mergePdfs(files);if(name==="ocr")await imageToText(files[0]);setStatus("Done. Your result is ready.");}catch(err){console.error(err);setStatus(err.message||"Something went wrong. Please try another file.",true);}finally{run.disabled=false;}});
  $("#workspace").scrollIntoView({behavior:"smooth",block:"start"});
}
function hintText(s){return s.replaceAll("&","&amp;").replaceAll("<","&lt;").replaceAll(">","&gt;");}
function formatSize(bytes){if(bytes<1024)return bytes+" B";if(bytes<1048576)return (bytes/1024).toFixed(1)+" KB";return (bytes/1048576).toFixed(2)+" MB";}
function showDownload(blob,filename,label="Download your file"){const url=URL.createObjectURL(blob);$("#result").innerHTML=`<div class="result-box">✓ ${label}: <a href="${url}" download="${filename}">${filename}</a></div>`;}
async function jpgToPdf(files){
  if(!window.PDFLib)throw new Error("PDF library did not load. Check your internet connection and refresh.");
  const {PDFDocument}=PDFLib;const pdf=await PDFDocument.create();
  for(const file of files){if(!["image/jpeg","image/png"].includes(file.type))continue;const bytes=await file.arrayBuffer();const img=file.type==="image/png"?await pdf.embedPng(bytes):await pdf.embedJpg(bytes);const page=pdf.addPage([img.width,img.height]);page.drawImage(img,{x:0,y:0,width:img.width,height:img.height});}
  if(!pdf.getPageCount())throw new Error("Please choose JPG or PNG images.");const bytes=await pdf.save();showDownload(new Blob([bytes],{type:"application/pdf"}),"filefixer-images.pdf");
}
async function compressImage(file,quality){
  if(!file)throw new Error("Choose an image first.");const img=await createImageBitmap(file);const canvas=document.createElement("canvas");canvas.width=img.width;canvas.height=img.height;const ctx=canvas.getContext("2d");ctx.fillStyle="#ffffff";ctx.fillRect(0,0,canvas.width,canvas.height);ctx.drawImage(img,0,0);img.close?.();
  const type=file.type==="image/png"?"image/png":"image/jpeg";const blob=await new Promise((resolve,reject)=>canvas.toBlob(b=>b?resolve(b):reject(new Error("Could not compress this image.")),type,quality));const ext=type==="image/png"?"png":"jpg";showDownload(blob,`compressed-image.${ext}`,`Compressed size ${formatSize(blob.size)} (original ${formatSize(file.size)})`);
}
async function mergePdfs(files){
  if(!window.PDFLib)throw new Error("PDF library did not load. Check your internet connection and refresh.");
  const {PDFDocument}=PDFLib;const merged=await PDFDocument.create();
  for(const file of files){if(file.type!=="application/pdf"&&!file.name.toLowerCase().endsWith(".pdf"))continue;const source=await PDFDocument.load(await file.arrayBuffer());const pages=await merged.copyPages(source,source.getPageIndices());pages.forEach(p=>merged.addPage(p));}
  if(!merged.getPageCount())throw new Error("No valid PDF pages found.");const bytes=await merged.save();showDownload(new Blob([bytes],{type:"application/pdf"}),"merged-file.pdf");
}
async function imageToText(file){
  if(!file)throw new Error("Choose an image first.");if(!window.Tesseract)throw new Error("OCR library did not load. Check your internet connection and refresh.");
  setStatus("Loading OCR engine and recognizing text. This may take a little time…");
  const result=await Tesseract.recognize(file,"eng",{logger:m=>{if(m.status==="recognizing text")setStatus(`Recognizing text: ${Math.round((m.progress||0)*100)}%`);}});
  const text=result.data.text.trim();if(!text)throw new Error("No text found. Try a clearer image.");
  $("#result").innerHTML=`<div class="result-box"><b>Text extracted successfully</b><textarea id="ocrText" style="display:block;width:100%;min-height:150px;margin:12px 0;padding:10px;border:1px solid #cce8da;border-radius:7px;font:12px/1.6 monospace;color:#243044">${escapeHtml(text)}</textarea><button class="action-button" id="copyText">Copy text</button> <button class="action-button secondary-button" id="downloadText">Download TXT</button></div>`;
  $("#copyText").addEventListener("click",async()=>{await navigator.clipboard.writeText($("#ocrText").value);setStatus("Text copied to clipboard.");});
  $("#downloadText").addEventListener("click",()=>showDownload(new Blob([$("#ocrText").value],{type:"text/plain"}),"extracted-text.txt","Text file ready"));
}
function escapeHtml(s){return s.replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
document.querySelectorAll("[data-open]").forEach(btn=>btn.addEventListener("click",()=>openTool(btn.dataset.open)));
