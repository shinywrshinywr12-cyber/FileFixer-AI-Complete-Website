# FileFixer AI — starter website

A responsive static website with four browser-side tools:
1. JPG/PNG to PDF
2. Image compressor (JPG/PNG/WebP input)
3. Merge PDF
4. Image to text (English OCR)

## Files
- `index.html` — homepage and tool workspace
- `styles.css` — responsive styling
- `app.js` — tool logic
- `privacy.html`, `terms.html` — starter legal pages
- `assets/favicon.svg` — favicon

## Run locally
Open `index.html` in a modern browser. For best results, use a local static server:
- VS Code: install Live Server and click “Go Live”, or
- Python: `python -m http.server 8000` then visit `http://localhost:8000`

The PDF and OCR libraries load from public CDNs, so an internet connection is required.

## Publish free with Cloudflare Pages (GitHub method)
1. Create a GitHub account and sign in.
2. Create a **public** repository named `filefixer-ai`.
3. Upload all files and folders from this project. `index.html` must be in the repository root.
4. Sign in to Cloudflare and open **Workers & Pages**.
5. Choose **Create application → Pages → Connect to Git**.
6. Connect GitHub and select `filefixer-ai`.
7. Framework preset: **None**. Build command: leave blank. Build output directory: `/` (or `.` if requested by the dashboard).
8. Deploy. Cloudflare will provide a `*.pages.dev` address.
9. Open the address on your phone and test all four tools.

Cloudflare dashboard labels can change. If the Git integration asks for a build output folder, use the repository root (`/`) because this is a plain static site.

## Before public launch
- Replace `hello@example.com` in `index.html`, `privacy.html`, and `terms.html` with a real support email.
- Confirm the brand name is available and does not infringe another business's trademark.
- Test with sample files on Android, iPhone and desktop browsers.
- Add a custom domain only after the free site works.
- Add analytics/ads/payment only after updating the privacy policy and checking provider eligibility and applicable laws.
- Do not claim “AI-powered” OCR: this starter uses Tesseract.js OCR, not a generative AI model.
- The site does not currently include accounts, cloud storage, subscriptions, payment processing, admin dashboard or usage limits.

## Technical notes
- PDF creation and merging use `pdf-lib`.
- OCR uses `Tesseract.js` with English (`eng`) by default.
- External libraries are loaded from CDN URLs in `index.html`; if a CDN is blocked or unavailable, the corresponding tool will not work.
- Image compression uses browser canvas. PNG transparency is flattened onto white to ensure consistent output.
- For production, consider adding file-size limits, accessibility testing, automated tests, dependency pinning/self-hosting, abuse monitoring, and clear retention/security documentation.
